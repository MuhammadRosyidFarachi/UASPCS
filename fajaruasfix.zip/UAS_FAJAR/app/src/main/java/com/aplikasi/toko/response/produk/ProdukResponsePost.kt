package com.aplikasi.toko.response.produk

data class ProdukResponsePost (
    val `data`: Data,
    val message: String,
    val success: Boolean
)