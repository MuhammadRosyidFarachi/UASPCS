package com.aplikasi.toko.response.login

data class LoginResponse(
    val success:Boolean,
    val message:String,
    val data:Data
)

